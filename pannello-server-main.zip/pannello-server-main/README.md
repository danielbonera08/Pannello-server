# Il pannello dei server

Dashboard realizzata in React con Vite che mostra lo stato di sei server aziendali distribuiti tra Milano e Francoforte: quanti sono online, quanti sono sotto sforzo, qual è il server più lento e quali avvisi sono in corso.

Il progetto è un esercizio di **React senza stato**: tutti i dati vivono in `App` e scendono ai componenti tramite `props` di sola lettura. L'interfaccia è dichiarativa: se cambiano i dati, la pagina si aggiorna da sola senza toccare i componenti.

---

## Indice

- [Prerequisiti](#prerequisiti)
- [Scaricare il progetto](#scaricare-il-progetto)
- [Installare e avviare la dashboard](#installare-e-avviare-la-dashboard)
- [Comandi disponibili](#comandi-disponibili)
- [Struttura del progetto](#struttura-del-progetto)
- [Come funziona](#come-funziona)
- [Verifica rapida](#verifica-rapida)
- [Personalizzare la dashboard](#personalizzare-la-dashboard)
- [Crediti](#crediti)

---

## Prerequisiti

- **Node.js** 22 o superiore (il progetto è stato sviluppato e verificato con Node.js 26.13.0)
- **npm** 10 o superiore (verificato con npm 12.2.2)
- Un browser moderno (Chrome, Edge, Firefox o Safari)

Per controllare di avere tutto:

```bash
node --version
npm --version
```

---

## Scaricare il progetto

### Opzione A — con Git (consigliata)

```bash
git clone https://github.com/bottafrancesca/pannello-server.git
cd pannello-server
```

### Opzione B — scaricare lo ZIP

1. Apri la pagina del repository su GitHub.
2. Clicca su **Code** → **Download ZIP**.
3. Estrai l'archivio in una cartella a piacere.
4. Apri un terminale dentro la cartella estratta (`cd percorso/pannello-server`).

> La cartella `node_modules` non fa parte del repository: viene creata al passaggio successivo con `npm install`.

---

## Installare e avviare la dashboard

Dentro la cartella del progetto esegui:

```bash
npm install
npm run dev
```

Vite stampa in terminale un indirizzo simile a:

```
  VITE v8.3.8  ready in 300 ms

  ➜  Local:   http://localhost:5173/
```

Apri <http://localhost:5173/> nel browser. Per fermare il server premi `Ctrl + C` nel terminale.

Se la porta 5173 è già occupata, Vite propone automaticamente la successiva (5174, 5175, …) e la indicano quei messaggi in terminale.

---

## Comandi disponibili

| Comando | Cosa fa |
| --- | --- |
| `npm run dev` | Avvia il server di sviluppo con hot reload |
| `npm run build` | Crea la versione ottimizzata nella cartella `dist/` |
| `npm run preview` | Serve localmente la build di produzione |
| `npm run lint` | Controlla il codice con Oxlint |

Per distribuire il sito, carica il contenuto di `dist/` su qualsiasi hosting statico (GitHub Pages, Netlify, Vercel, un semplice server Nginx).

---

## Struttura del progetto

```
pannello-server/
├── index.html              # Pagina HTML di partenza (contiene <div id="root">)
├── package.json            # Dipendenze e script npm
├── vite.config.js          # Configurazione di Vite + plugin React
├── risposte.md             # Risposte alle domande sul flusso dei dati
└── src/
    ├── main.jsx            # Monta <App /> in StrictMode
    ├── index.css           # Foglio di stile globale (svuotato)
    ├── App.jsx             # Componente radice: importa i dati, calcola, passa giù
    ├── App.css             # Foglio di stile fornito per l'esercizio
    ├── dati.js             # I dati originali (NON modificare)
    ├── dati-blackout.js    # Gli stessi server, tutti spenti (sfida)
    ├── calcoli.js          # Funzioni JavaScript pure, senza JSX
    ├── Intestazione.jsx    # Fascia blu con nome e conteggio
    ├── Riepilogo.jsx       # Sei caselle di numeri
    ├── GrigliaServer.jsx   # Griglia con le sei schede
    ├── SchedaServer.jsx    # Scheda di un singolo server
    ├── BadgeStato.jsx      # Etichetta colorata dello stato
    ├── ServerInEvidenza.jsx# Server cercato per nome
    └── Avvisi.jsx          # Riquadro degli avvisi
```

---

## Come funziona

### 1. I dati (`src/dati.js`)

`dati.js` esporta tre costanti:

| Export | Contenuto |
| --- | --- |
| `sistema` | Nome della piattaforma e data dell'ultimo aggiornamento |
| `servers` | Array di sei oggetti server |
| `avvisi` | Array di due stringhe |

Ogni server ha `nome`, `ruolo`, `sede`, `ip`, `online`, `cpu`, `latenza`, `servizi` e, facoltativamente, `manutenzione`. Quando un server è offline, `cpu` e `latenza` valgono `null`; `servizi` può essere un array vuoto; `manutenzione` può mancare del tutto. Questi casi "difficili" sono proprio quelli che l'interfaccia deve gestire senza errori.

### 2. La logica (`src/calcoli.js`)

Il file contiene solo JavaScript: nessun JSX e nessuna React. Le funzioni ricevono dati e restituiscono valori, quindi sono **pure** e facilmente verificabili.

| Funzione | Cosa restituisce |
| --- | --- |
| `statoServer(server)` | `"offline"`, `"critico"`, `"attenzione"` o `"ok"` |
| `contaPerStato(servers, stato)` | Quanti server sono in quello stato |
| `cpuMedia(servers)` | Media CPU dei soli server online, oppure `null` se non ce ne sono |
| `piuLento(servers)` | L'oggetto server online con latenza maggiore, oppure `null` |
| `trovaServer(servers, nome)` | Il server con quel nome, oppure `undefined` |

Le soglie sono in `SOGLIE = { attenzione: 70, critico: 90 }` e **non** sono scritte a mano nelle condizioni. Lo stato si calcola in quest'ordine:

1. `online === false` → **offline**
2. `cpu >= 90` → **critico**
3. `cpu >= 70` → **attenzione**
4. altrimenti → **ok**

L'ordine conta: `cache-01` è offline e ha `cpu: null`, quindi va verificato per primo; `db-02` ha esattamente il 70% ed è "attenzione" perché la soglia è inclusiva.

### 3. L'albero dei componenti

```
App                      ← importa i dati, calcola, passa giù
 ├── Intestazione         ← nome, aggiornamento, quanti online
 ├── Riepilogo            ← sei caselle di numeri
 ├── GrigliaServer        ← riceve l'array dei server
 │    └── SchedaServer ×6 ← riceve un server
 │         └── BadgeStato ← riceve solo lo stato
 ├── ServerInEvidenza     ← il server cercato per nome
 │    └── SchedaServer    ← lo stesso componente, riusato
 └── Avvisi               ← un array di stringhe
```

| Componente | Prop | Tipo |
| --- | --- | --- |
| `Intestazione` | `nome`, `aggiornato`, `online`, `totale` | stringhe e numeri |
| `Riepilogo` | `ok`, `attenzione`, `critici`, `offline`, `mediaCpu`, `lento` | numeri, `null`, oggetto |
| `GrigliaServer` | `servers` | array di server |
| `SchedaServer` | `server` | oggetto intero |
| `BadgeStato` | `stato` | stringa |
| `ServerInEvidenza` | `cercato`, `server` | stringa, oggetto o `undefined` |
| `Avvisi` | `elenco` | array di stringhe |

`App` è l'unico posto che conosce i dati:
calcola `online`, i quattro conteggi, la media e il server più lento, poi passa ogni valore al componente che lo mostra. Nessun componente modifica ciò che riceve: non c'è `useState` e non ci sono pulsanti, perché il pannello **mostra** dati.

Per questo motivo `statoServer` può essere chiamata due volte — in `SchedaServer` per colorare la scheda e in `contaPerStato` per il riepilogo — senza mai disallinearsi: stessa funzione pura + stessi dati = stesso risultato.

### 4. Casi limite gestiti

- **CPU a 0** (`backup-01`): il controllo è `cpu === null`, non `cpu ? ...`, perché lo zero è *falsy* ma è un valore valido.
- **Array vuoto**: `servizi.length === 0` produce `Servizi: nessuno` e `elenco.length === 0` produce `Nessun avviso` su sfondo verde. Un array vuoto è *truthy*, quindi controllare la `length` è indispensabile.
- **Proprietà mancante**: `manutenzione ? ... : "nessuna in programma"` evita di leggere `manutenzione.data` su un oggetto inesistente.
- **Nessun server online**: `cpuMedia` restituisce `null` invece di `NaN` e `piuLento` restituisce `null` invece di far crashare `reduce`.

### 5. La sfida del blackout (`src/dati-blackout.js`)

Il file contiene gli stessi sei server, tutti spenti, e zero avvisi. Per vedere l'effetto basta cambiare **una sola riga** in `App.jsx`:

```jsx
import { sistema, servers, avvisi } from "./dati-blackout"
```

La pagina mostra subito 0 server online, sei schede grigie, `—` nella CPU media e nel più lento, e `Avvisi (0)` su sfondo verde. Nessun componente è stato toccato: è il flusso unidirezionale dei dati a fare il lavoro. Al termine ripristina `"./dati"`.

---

## Verifica rapida

Con i dati originali, in console dovresti vedere (il valore è stampato due volte perché `main.jsx` usa `StrictMode`):

```
6 2
6 2
```

I valori calcolati attesi sono:

| Controllo | Risultato |
| --- | --- |
| Stati dei server | `ok attenzione critico / attenzione offline ok` |
| Conteggi (ok, attenzione, critici, offline) | `2 2 1 1` |
| CPU media | `55` → mostrata come `55.0%` |
| Server più lento | `backup-01`, `120 ms` |
| Ricerca `db-01` | IP `10.0.2.21` |
| Ricerca `web-09` | `undefined` → "Nessun server si chiama web-09" |

Le risposte alle domande sul flusso dei dati sono in [`risposte.md`](risposte.md) e in fondo a `src/App.jsx`.

---

## Personalizzare la dashboard

- **Cambiare il server cercato**: modifica `const cercato = "db-01"` in `src/App.jsx`. Prova `"cache-01"` o `"web-09"` per vedere il ternario fra due pezzi di JSX.
- **Aggiungere server**: modifica `src/dati.js` e aggiungi una riga `<SchedaServer server={servers[6]} />` in `GrigliaServer.jsx` (le schede sono scritte a mano; `map()` arriva alla settimana 8).
- **Cambiare i colori**: tutte le classi (`scheda-*`, `badge-*`, `avvisi-*`) sono in `src/App.css`.

---

## Crediti

Esercizio di laboratorio "Il pannello dei server" dal materiale didattico originale della **Prof.ssa Paola Bertulli** (a.s. 2026/27). I dati sono inventati per l'esercizio e le soglie del 70% e 90% sono scelte didattiche, non valori standard.
