# Tre domande sul flusso dei dati

## 1. Il pulsante «Riavvia»

Non si fa: le props sono di sola lettura e il flusso dei dati è unidirezionale, quindi `SchedaServer` può solo mostrare `server.online`, non scriverlo. Il dato `online` vive in `App` (nei dati importati da `./dati`) ed è lì che andrebbe cambiato, non nel componente che lo riceve. A fine settimana 7 manca `useState`: senza uno stato gestito da React, nemmeno `App` potrebbe far ricalcolare l'interfaccia.

## 2. Lo stato calcolato due volte

`statoServer` è una funzione pura: dati uguali, risultato uguale. Sia la griglia sia il riepilogo la chiamano con lo stesso oggetto, quindi non possono esserci due fonti di verità: se due schede sono rosse, la casella «Critici» dirà necessariamente 2. Non esiste un caso in cui i due valori divergano, perché nessuno dei due calcola lo stato in modo diverso o lo conserva dentro uno stato proprio.

## 3. Chi riceve cosa

Prendo `BadgeStato`: riceve solo la stringa `stato`, non l'oggetto `server`. Guadagni: è un componente piccolo e specializzato, che conosce solo quattro valori e ha un unico compito (mostrare colore ed etichetta), quindi è facile da capire, riusare e verificare; se cambi la struttura dell'oggetto server, il badge non deve essere toccato.
