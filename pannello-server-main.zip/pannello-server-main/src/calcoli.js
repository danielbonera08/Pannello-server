// src/calcoli.js — solo JavaScript: funzioni che ricevono dati e restituiscono valori.

export const SOGLIE = { attenzione: 70, critico: 90 }

export function statoServer(server) {
  return !server.online
    ? "offline"
    : server.cpu >= SOGLIE.critico
      ? "critico"
      : server.cpu >= SOGLIE.attenzione
        ? "attenzione"
        : "ok"
}

export function contaPerStato(servers, stato) {
  return servers.filter((s) => statoServer(s) === stato).length
}

export function cpuMedia(servers) {
  const online = servers.filter((s) => s.online)
  if (online.length === 0) return null
  return online.reduce((somma, s) => somma + s.cpu, 0) / online.length
}

export function piuLento(servers) {
  const online = servers.filter((s) => s.online)
  return online.reduce((lento, s) => {
    if (lento === null || s.latenza > lento.latenza) return s
    return lento
  }, null)
}

export function trovaServer(servers, nome) {
  return servers.find((s) => s.nome === nome)
}
