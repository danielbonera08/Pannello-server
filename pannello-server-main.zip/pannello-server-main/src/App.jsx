import './App.css'
import { sistema, servers, avvisi } from "./dati"
import { contaPerStato, cpuMedia, piuLento, trovaServer } from "./calcoli"
import Intestazione from "./Intestazione"
import Riepilogo from "./Riepilogo"
import GrigliaServer from "./GrigliaServer"
import ServerInEvidenza from "./ServerInEvidenza"
import Avvisi from "./Avvisi"

export default function App() {
  // Richiesta 1: quanti server e quanti avvisi (in StrictMode la riga appare due volte).
  console.log(servers.length, avvisi.length)

  const online = servers.filter((s) => s.online).length
  const cercato = "db-01"

  return (
    <div className="pannello">
      <Intestazione
        nome={sistema.nome}
        aggiornato={sistema.aggiornato}
        online={online}
        totale={servers.length}
      />
      <Riepilogo
        ok={contaPerStato(servers, "ok")}
        attenzione={contaPerStato(servers, "attenzione")}
        critici={contaPerStato(servers, "critico")}
        offline={contaPerStato(servers, "offline")}
        mediaCpu={cpuMedia(servers)}
        lento={piuLento(servers)}
      />
      <GrigliaServer servers={servers} />
      <ServerInEvidenza cercato={cercato} server={trovaServer(servers, cercato)} />
      <Avvisi elenco={avvisi} />
    </div>
  )
}

/*
  il blackout 

  1. Se dati-blackout.js avesse sette server, nella griglia continuerei a vedere
     sei schede: GrigliaServer usa sei <SchedaServer> scritti a mano, da
     servers[0] a servers[5], e il settimo dato non verrebbe mostrato; con map()
     (settimana 8) comparirebbe anche lui. Se ne avesse cinque, le prime cinque
     schede apparirebbero normali, ma servers[5] sarebbe undefined e SchedaServer
     si fermerebbe nel tentativo di leggere le sue proprietà: pagina bianca.

  2. Il flusso unidirezionale dei dati: i componenti non hanno stato, sono
     funzioni pure di quello che ricevono via props. Se cambiano i dati in
     ingresso, l'interfaccia si ricalcola da sola. Per questo è bastato cambiare
     una sola riga (l'import) senza toccare i sei componenti.
*/
